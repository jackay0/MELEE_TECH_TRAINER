import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

public class ButtonFlash {                    //this is not to be confused with the NOTE class which will be the moving notes that fall on screen

    private double x;
    private double y;
    GameWindow g;
    private BufferedImage abutton2; //sprite for white a button
    private BufferedImage bbutton2; //sprite for b button
    private BufferedImage xbutton2; //sprite for x button
    private BufferedImage ybutton2; //sprite for y button
    private BufferedImage lbutton2;
    private BufferedImage rbutton2;
    private BufferedImage startbutton2;
    private BufferedImage zbutton2;


    public ButtonFlash(double x, double y, GameWindow g) {
        this.x = x;
        this.y = y;
        this.g = g;
        SpriteSheet z = new SpriteSheet(g.getSpriteSheet());
        abutton2 = z.grabImage(3, 4, 32, 32);
        bbutton2 = z.grabImage(4, 4, 32, 32);
        xbutton2 = z.grabImage(6, 4, 32, 32);
        ybutton2 = z.grabImage(5, 4, 32, 32);
        lbutton2 = z.grabImage(1, 5, 32, 32);
        rbutton2 = z.grabImage(2, 5, 32, 32);
        startbutton2 = z.grabImage(8, 4, 32, 32);
        zbutton2 = z.grabImage(7, 4, 32, 32);
    }


    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_A) {
            x = 400;
            y = 400;
        }
        if (e.getKeyCode() == KeyEvent.VK_B) {
            x = 360;
            y = 420;
        }
        if (e.getKeyCode() == KeyEvent.VK_X) {
            x = 440;
            y = 385;
        }
        if (e.getKeyCode() == KeyEvent.VK_Y) {
            x = 385;
            y = 370;
        }
        if (e.getKeyCode() == KeyEvent.VK_L) {
            x = 250;
            y = 340;
        }
        if (e.getKeyCode() == KeyEvent.VK_R) {
            x = 405;
            y = 340;
        }
        if (e.getKeyCode() == KeyEvent.VK_S) {
            x = 300;
            y = 420;
        }
        if (e.getKeyCode() == KeyEvent.VK_Z) {
            x = 390;
            y = 350;
        }

    }

    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_A) {
            //System.out.println("a");
            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_B) {
            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_X) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_Y) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_L) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_R) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_S) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_Z) {

            x = -100;
            y = -100;
        }
    }

    public void tick() //update method
    {


    }


    public void render(Graphics g)  //draws out image
    {
        if (x == 400 && y == 400) {
            g.drawImage(abutton2, (int) x, (int) y, null);
        }
        if (x == 360 && y == 420) {
            g.drawImage(bbutton2, (int) x, (int) y, null);
        }
        if (x == 440 && y == 385) {
            g.drawImage(xbutton2, (int) x, (int) y, null);
        }
        if (x == 385 && y == 370) {
            g.drawImage(ybutton2, (int) x, (int) y, null);
        }
        if (x == 250 && y == 340) {
            g.drawImage(lbutton2, (int) x, (int) y, null);
        }
        if (x == 405 && y == 340) {
            g.drawImage(rbutton2, (int) x, (int) y, null);
        }
        if (x == 300 && y == 420) {
            g.drawImage(startbutton2, (int) x, (int) y, null);
        }
        if (x == 390 && y == 350) {
            g.drawImage(zbutton2, (int) x, (int) y, null);
        }

    }


}


