import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Scanner;

public class Input extends KeyAdapter{

//below is a tester for joytokey: press ab on controller and then enter on the keyboard	
	//public static void main(String[] args) {
		//Scanner x = new Scanner(System.in);
		
		//String r = x.next(); 
		
		//if(r.equals("ab")) 
				//{
			
				//System.out.println(("mission successful"));
				//}
		//}
GameWindow win;
	
public Input(GameWindow win)
{
	this.win = win;

}
	
	
public void keyPressed(KeyEvent a) {
	win.keyPressed(a);
	
	}


public void keyReleased(KeyEvent a) {
	win.keyReleased(a);
	
}

}





