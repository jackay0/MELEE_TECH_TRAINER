import java.awt.Graphics;
import java.awt.Color;
import java.awt.image.BufferedImage;

public class Button //this class will be for all button objects, aka the buttons at the bottom of the screen that flash a diff color at the input of that button
{					//this is not to be confused with the NOTE class which will be the moving notes that fall on screen

private double x;
private double y;

private BufferedImage abutton; //sprite for a button
private BufferedImage bbutton; //sprite for b button
private BufferedImage xbutton; //sprite for x button
private BufferedImage ybutton; //sprite for y button



public Button(double x, double y, GameWindow g)
{
	this.x = x;
	this.y = y;
	SpriteSheet z = new SpriteSheet(g.getSS());
	abutton = z.grabImage(1,1,32,32);
	bbutton = z.grabImage(2,1,32,32);
}

public void tick() //update method
{
	
}


public void render(Graphics g)  //draws out image
{
	g.drawImage(abutton, (int) x,  (int) y, null);
	
}

public void chngColor() //this method is where we will somehow change the color of the sprite, either changing the sprite with a diff colored one or somehow changing rgb values
{
	
}

}

