import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import com.game.src.main.classes.EntityB;

public class ButtonFlash extends GameObject implements EntityB { // this is not to be confused with the NOTE class which
																	// will be the moving notes that fall on screen
	// this is not to be confused with the NOTE class which will be the moving notes
	// that fall on screen

    private double i;
	private int z;
	GameWindow g;
	private BufferedImage abutton2; // sprite for white a button
	private BufferedImage bbutton2; // sprite for b button
	private BufferedImage xbutton2; // sprite for x button
	private BufferedImage ybutton2; // sprite for y button
	private BufferedImage lbutton2;
	private BufferedImage rbutton2;
	private BufferedImage startbutton2;
	
	

	public ButtonFlash(double x, double y, GameWindow g) {
		super(x, y);
		this.g = g;
		SpriteSheet ss = new SpriteSheet(g.getSpriteSheet());
		abutton2 = ss.grabImage(3, 4, 32, 32);
		bbutton2 = ss.grabImage(4, 4, 32, 32);
		xbutton2 = ss.grabImage(6, 4, 32, 32);
		ybutton2 = ss.grabImage(5, 4, 32, 32);
		lbutton2 = ss.grabImage(1, 5, 32, 32);
		rbutton2 = ss.grabImage(2, 5, 32, 32);
		startbutton2 = ss.grabImage(8, 4, 32, 32);
	
		

	}

	public void keyPressed(KeyEvent e) {

    	if (e.getKeyCode() == KeyEvent.VK_A) {
            x = 327;
            y = 367;
            i++;
        }
      
        if (e.getKeyCode() == KeyEvent.VK_X) {
            x = 339;
            y = 356;
        }
        if (e.getKeyCode() == KeyEvent.VK_Y) {
            x = 319;
            y = 353;
        }
        if (e.getKeyCode() == KeyEvent.VK_L) {
            x = 238;
            y = 336;
        }
        if (e.getKeyCode() == KeyEvent.VK_R) {
            x = 327;
            y = 336;
        }
        if (e.getKeyCode() == KeyEvent.VK_S) {
            x = 282;
            y = 375;
        
        }
        
	}

	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_A) {
			// System.out.println("a");
			x = -100;
			y = -100;
		}
		if (e.getKeyCode() == KeyEvent.VK_X) {

			x = -100;
			y = -100;
		}
		if (e.getKeyCode() == KeyEvent.VK_Y) {

			x = -100;
			y = -100;
		}
		if (e.getKeyCode() == KeyEvent.VK_L) {

			x = -100;
			y = -100;
		}
		if (e.getKeyCode() == KeyEvent.VK_R) {

			x = -100;
			y = -100;
		}
		if (e.getKeyCode() == KeyEvent.VK_S) {

			x = -100;
			y = -100;
		}
	
	}

	public void tick() // update method
	{

	}

	public void render(Graphics g) // draws out image
	{
		if (x == 327 && y == 367) {
            g.drawImage(abutton2, (int) x, (int) y, null);
        }
        if (x == 313 && y == 372) {
            g.drawImage(bbutton2, (int) x, (int) y, null);
        }
        if (x == 339 && y == 356) {
            g.drawImage(xbutton2, (int) x, (int) y, null);
        }
        if (x == 319 && y == 353) {
            g.drawImage(ybutton2, (int) x, (int) y, null);
        }
        if (x == 238 && y == 336) {
            g.drawImage(lbutton2, (int) x, (int) y, null);
        }
        if (x == 282 && y == 375) {
            g.drawImage(startbutton2, (int) x, (int) y, null);
        }
        if (x == 327 && y == 336) {
            g.drawImage(rbutton2, (int) x, (int) y, null);
        }
       
	}

	@Override
	public double getX() {
		// TODO Auto-generated method stub
		return x;
	}

	@Override
	public double getY() {
		// TODO Auto-generated method stub
		return y;
	}

	public double getI() {
		return i;
	}
	public void setI(double i) {
	   this.i = i;
	}
	public Rectangle getBounds() {

		return new Rectangle((int) x, (int) y, 32, 32);
	}

}
