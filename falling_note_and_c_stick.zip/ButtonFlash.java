import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

public class ButtonFlash {  //this is not to be confused with the NOTE class which will be the moving notes that fall on screen

    private double x;
    private double y;
    private int z;
    GameWindow g;
   //these are the images that will be the white variants of each button, hence the '2'
    private BufferedImage abutton2; 
    private BufferedImage bbutton2; 
    private BufferedImage xbutton2; 
    private BufferedImage ybutton2; 
    private BufferedImage lbutton2;
    private BufferedImage rbutton2;
    private BufferedImage startbutton2;
    private BufferedImage zbutton2;
    
    //cstick
    private BufferedImage cup;
    private BufferedImage cdown;
    private BufferedImage cleft;
    private BufferedImage cright;
   
    
    //c stick diagonals
    private BufferedImage cur;
    private BufferedImage cul;
    private BufferedImage cdr;
    private BufferedImage cdl;
    
    
    
    public ButtonFlash(double x, double y, GameWindow g) {
        this.x = x;
        this.y = y;
        this.g = g;
        SpriteSheet z = new SpriteSheet(g.getSpriteSheet());
        //A B X Y Z
        abutton2 = z.grabImage(3, 4, 32, 32);
        bbutton2 = z.grabImage(4, 4, 32, 32);
        xbutton2 = z.grabImage(6, 4, 32, 32);
        ybutton2 = z.grabImage(5, 4, 32, 32);
        lbutton2 = z.grabImage(1, 5, 32, 32);
        rbutton2 = z.grabImage(2, 5, 32, 32);
        startbutton2 = z.grabImage(8, 4, 32, 32);
        zbutton2 = z.grabImage(7, 4, 32, 32);
        //c stick
        cdown = z.grabImage(4, 6, 32, 32);
        cup = z.grabImage(7, 6, 32, 32);
        cleft = z.grabImage(1, 7, 32, 32);
        cright = z.grabImage(2, 7, 32, 32);
        //c stick diagonals
        cur = z.grabImage(8, 6, 32, 32);
        cul = z.grabImage(6, 6, 32, 32);
        cdr = z.grabImage(6, 6, 32, 32);
        cdl = z.grabImage(3, 6, 32, 32);
        cdr = z.grabImage(5, 6, 32, 32);
    
    }


    public void keyPressed(KeyEvent e) {
       //A B X Y Z
    	if (e.getKeyCode() == KeyEvent.VK_A) {
            x = 400;
            y = 400;
        }
        if (e.getKeyCode() == KeyEvent.VK_B) {
            x = 360;
            y = 420;
        }
        if (e.getKeyCode() == KeyEvent.VK_X) {
            x = 440;
            y = 385;
        }
        if (e.getKeyCode() == KeyEvent.VK_Y) {
            x = 385;
            y = 370;
        }
        if (e.getKeyCode() == KeyEvent.VK_L) {
            x = 250;
            y = 340;
        }
        if (e.getKeyCode() == KeyEvent.VK_R) {
            x = 405;
            y = 340;
        }
        if (e.getKeyCode() == KeyEvent.VK_S) {
            x = 300;
            y = 420;
        }
        if (e.getKeyCode() == KeyEvent.VK_Z) {
            x = 390;
            y = 350;
        }
        //c stick (needs a z coord simply because there are so many sprites going into 390, 440)
        // maybe, if one key is pressed, move two sprites?
        if (e.getKeyCode() == KeyEvent.VK_U) {
            x = 390;
            y = 440;
            z=1;
        }
        if (e.getKeyCode() == KeyEvent.VK_H) {
        	 x = 390;
             y = 440;
             z= 2;
        }
        if (e.getKeyCode() == KeyEvent.VK_J) {
        	 x = 390;
             y = 440;
             z = 3;
        }
        if (e.getKeyCode() == KeyEvent.VK_K) {
        	 x = 390;
             y = 440;
             z = 4;
        }
        
        // c stick diagonal inputs
        if (e.getKeyCode() == KeyEvent.VK_7) {
        	x = 390;
        	y = 440;
            z = 5;
        }
        if (e.getKeyCode() == KeyEvent.VK_I) {
        	x = 390;
        	y = 440;
            z = 6;
        }
        if (e.getKeyCode() == KeyEvent.VK_N) {
        	x = 390;
        	y = 440;
            z = 7;
        }
        if (e.getKeyCode() == KeyEvent.VK_M) {
        	x = 390;
        	y = 440;
            z = 8;
        }
    
    }

    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_A) {
            //System.out.println("a");
            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_B) {
            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_X) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_Y) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_L) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_R) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_S) {

            x = -100;
            y = -100;
        }
        if (e.getKeyCode() == KeyEvent.VK_Z) {

            x = -100;
            y = -100;
        }
        //c stick diagonals: // try an if statement within an if statement? instead of the and?
        if (e.getKeyCode() == KeyEvent.VK_7) {
            x = -100;
            y = -100;
            z=0;
        }
        if (e.getKeyCode() == KeyEvent.VK_I) {
            x = -100;
            y = -100;
            z=0;
        }
        if (e.getKeyCode() == KeyEvent.VK_N) {
            x = -100;
            y = -100;
            z=0;
        }
        if (e.getKeyCode() == KeyEvent.VK_M) {
            x = -100;
            y = -100;
            z=0;
        }
        
        
        // c stick
        if (e.getKeyCode() == KeyEvent.VK_U) {
            x = -100;
            y = -100;
            z=0;
        }
        if (e.getKeyCode() == KeyEvent.VK_H) {
        	 x = -100;
             y = -100;
             z= 0;
        }
        
        if (e.getKeyCode() == KeyEvent.VK_J) {
        	 x = -100;
             y = -100;
             z = 0;
        }
        if (e.getKeyCode() == KeyEvent.VK_K) {
        	 x = -100;
             y = -100;
             z = 0;
        }
    
    
    
    
    
    
    
    
    
    
    }

    public void tick() //update method
    {


    }


    public void render(Graphics g)  //draws out image
    {
        //BUTTONS
    	
    	if (x == 400 && y == 400) {
            g.drawImage(abutton2, (int) x, (int) y, null);
        }
        if (x == 360 && y == 420) {
            g.drawImage(bbutton2, (int) x, (int) y, null);
        }
        if (x == 440 && y == 385) {
            g.drawImage(xbutton2, (int) x, (int) y, null);
        }
        if (x == 385 && y == 370) {
            g.drawImage(ybutton2, (int) x, (int) y, null);
        }
        if (x == 250 && y == 340) {
            g.drawImage(lbutton2, (int) x, (int) y, null);
        }
        if (x == 405 && y == 340) {
            g.drawImage(rbutton2, (int) x, (int) y, null);
        }
        if (x == 300 && y == 420) {
            g.drawImage(startbutton2, (int) x, (int) y, null);
        }
        if (x == 390 && y == 350) {
            g.drawImage(zbutton2, (int) x, (int) y, null);
        }

        //CONTROL STICK	
        
        
        
        
        
        
        
        
        //c stick
        if (x == 390 && y == 440 && z == 1) {
            g.drawImage(cup, (int) x, (int) y, null);
        }
        if (x == 390 && y == 440 && z == 2) {
            g.drawImage(cleft, (int) x, (int) y, null);
        }
        if (x == 390 && y == 440 && z == 3) {
            g.drawImage(cdown, (int) x, (int) y, null);
        }
        if (x == 390 && y == 440 && z == 4) {
            g.drawImage(cright, (int) x, (int) y, null);
        }
        if (x == 390 && y == 440 && z == 5) {
            g.drawImage(cul, (int) x, (int) y, null);
        }
        if (x == 390 && y == 440 && z == 6) {
            g.drawImage(cur, (int) x, (int) y, null);
        }
        if (x == 390 && y == 440 && z == 7) {
            g.drawImage(cdl, (int) x, (int) y, null);
        }
        if (x == 390 && y == 440 && z == 8) {
            g.drawImage(cdr, (int) x, (int) y, null);
        }
    
    
    
    
    
    
    }


}


