import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.swing.JFrame;


public class GameWindow extends Canvas implements Runnable { //This interface is useful when utilizing multiple threads
    //In this case, it ensures that just because one Thread has been executed,
    //another won't simply stop its processes
    public static final int WIDTH = 320;
    public static final int HEIGHT = WIDTH / 12 * 9;
    public static final int SCALE = 2;
    public final String TITLE = "Melee Tech Trainer";

    private boolean running = false;
    private Thread thread;

    private BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
    private BufferedImage spriteSheet = null;

    //sprites for buttons on screen
    private BufferedImage abutton; 
    private BufferedImage bbutton; 
    private BufferedImage xbutton; 
    private BufferedImage ybutton; 
    private BufferedImage lbutton;
    private BufferedImage rbutton;
    private BufferedImage startbutton;
    private BufferedImage zbutton;
    private BufferedImage cstick; 
    
    
    private ButtonFlash cdown;
    private ButtonFlash cup;
    private ButtonFlash cleft;
    private ButtonFlash cright;
    
    
    private ButtonFlash abutton2;
    private ButtonFlash bbutton2;
    private ButtonFlash xbutton2;
    private ButtonFlash ybutton2;
    private ButtonFlash lbutton2;
    private ButtonFlash rbutton2;
    private ButtonFlash startbutton2;
    private ButtonFlash zbutton2;


    
    private Note anote;
    public void init() {


        BufferedImageLoader loader = new BufferedImageLoader();
        try { //try catch means: try to do this, if it cant be done, then catch, in this case an error report
            spriteSheet = loader.LoadImage("/Sprite_Sheet.png");
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Below are the buttonflash objects, which are the white button sprites. They are off screen until a button press
        abutton2 = new ButtonFlash(-100, -100, this);
        bbutton2 = new ButtonFlash(-100, -100, this);
        xbutton2 = new ButtonFlash(-100, -100, this);
        ybutton2 = new ButtonFlash(-100, -100, this);
        lbutton2 = new ButtonFlash(-100, -100, this);
        rbutton2 = new ButtonFlash(-100, -100, this);
        startbutton2 = new ButtonFlash(-100, -100, this);
        zbutton2 = new ButtonFlash(-100, -100, this);
       
        cup = new ButtonFlash(-100, -100, this);
        cdown = new ButtonFlash(-100, -100, this);
        cleft = new ButtonFlash(-100, -100, this);
        cright = new ButtonFlash(-100, -100, this);

        //These are the images for the regular buttons, not objects because their locations aren't manipulated.
        SpriteSheet ss = new SpriteSheet(spriteSheet);
        abutton = ss.grabImage(1, 1, 32, 32);
        bbutton = ss.grabImage(2, 1, 32, 32);
        xbutton = ss.grabImage(4, 1, 32, 32);
        ybutton = ss.grabImage(3, 1, 32, 32);
        lbutton = ss.grabImage(5, 1, 32, 32);
        rbutton = ss.grabImage(6, 1, 32, 32);
        startbutton = ss.grabImage(8, 1, 32, 32);
        zbutton = ss.grabImage(7, 1, 32, 32);
        cstick = ss.grabImage(2, 4, 32, 32);

    
        anote = new Note(400,60,this);
    
    
    
    
    
    
    }


    private synchronized void start() { //synchronization is an important thing when dealing with multiple Threads
        if (running) {                    //It defeats the purpose of working with multiple threads and errors occur without ensuring this
            return;                        //The following two methods ensure that threads are both serialized and executed
        }
        running = true;
        thread = new Thread(this);
        thread.start();

    }

    private synchronized void stop() {
        if (!running) {
            return;
        }
        running = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(1);

    }

    public static void main(String[] args) {
        GameWindow game = new GameWindow();
        game.setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE)); //Dimension class: simply  works with width and height variables to size the window
        game.setMaximumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
        game.setMinimumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
        game.setFocusable(false); //very important
        JFrame frame = new JFrame(game.TITLE);
        frame.add(game);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.pack();  //not sure what this does, supposedly an optimization
        frame.addKeyListener(game.new AL());
        game.start();


    }

    public void run() { //it is necessary to check if the program is 'running' or not because we implement runnable
        //this 'game loop' ensures it will run well on different computers, a lot of stuff will happen here: rendering, moving stuff, etc.
        init();


        long timerLast = System.nanoTime();
        final double ticks = 60.0; //every time it goes through the loop it will update 60 times
        double ns = 1000000000 / ticks;
        double chng = 0; //gets the time past, so it if fps or ticks run behind it will catch itself up
        int updater = 0; //# of ticks
        int fps = 0;     //fps
        long time = System.currentTimeMillis();

        while (running) {
            long current = System.nanoTime(); //because it takes time for it to get from outside the loop to inside, we don't want a small desync, the following
            chng += (current - timerLast) / ns; //the difference is null and the game is caught up
            timerLast = current;
            if (chng >= 1) {
                tick();
                updater++;
                chng--;
            }
            render();
            fps++;

            if (System.currentTimeMillis() - time > 1000) {
                time += 1000;
                System.out.println(updater + "Ticks. FPS:" + fps);
                updater = 0;
                fps = 0;
            }


            //System.out.println("WORKING");
        }
        stop();
    }

    private void tick() //everything in the game that updates
    {
    	anote.tick();

    }

    private void render() //everything in the game that renders
    {
        //creates a buffer strategy that handles all the buffering behind the scenes
        BufferStrategy bs = this.getBufferStrategy(); //returns a BufferStrategy
        if (bs == null) {
            createBufferStrategy(3); //We are going to have 3 buffers which increases loading speed over time
            return;
        }
        Graphics g = bs.getDrawGraphics();
        /////////////////////////////////////
        g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
        g.drawImage(abutton, 400, 400, this);  
        g.drawImage(bbutton, 360, 420, this);
        g.drawImage(xbutton, 440, 385, this);
        g.drawImage(ybutton, 385, 370, this);
        g.drawImage(lbutton, 250, 340, this);
        g.drawImage(rbutton, 405, 340, this);
        g.drawImage(startbutton, 300, 420, this);
        g.drawImage(zbutton, 390, 350, this);
        g.drawImage(cstick, 390, 440, this); //UHJK
        abutton2.render(g);
        bbutton2.render(g);
        xbutton2.render(g);
        ybutton2.render(g);
        lbutton2.render(g);
        rbutton2.render(g);
        startbutton2.render(g);
        zbutton2.render(g);
        
        cup.render(g);
        cdown.render(g);
        cleft.render(g);
        cright.render(g);

        
       anote.render(g);
        //////////////////////////////////// where we can draw images ^^^^^


        g.dispose();
        bs.show();

    }


    public BufferedImage getSpriteSheet() //this is a getter that will allow us to access the spritesheet from any other class
    {
        return spriteSheet;
    }

    //This class is used for the ButtonFlash class, enabling communication with the keyboard and the class
    public class AL extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            abutton2.keyPressed(e);
            bbutton2.keyPressed(e);
            xbutton2.keyPressed(e);
            ybutton2.keyPressed(e);
            lbutton2.keyPressed(e);
            rbutton2.keyPressed(e);
            startbutton2.keyPressed(e);
            zbutton2.keyPressed(e);
        }

        @Override
        public void keyReleased(KeyEvent e) {
            abutton2.keyReleased(e);
            bbutton2.keyReleased(e);
            xbutton2.keyReleased(e);
            ybutton2.keyReleased(e);
            lbutton2.keyReleased(e);
            rbutton2.keyReleased(e);
            startbutton2.keyReleased(e);
            zbutton2.keyReleased(e);
        }

    }
}