import java.awt.Graphics;
import java.util.LinkedList;

import com.game.src.main.classes.EntityA;
import com.game.src.main.classes.EntityB;
public class Controller {

// What is a linkedlist exactly? A group of nodes where each node contains a value and a reference to the next node in the list.
// a node has a data component and a reference to the next node
// a linked list is ONLY applicable if you plan on inserting several items and also somewhere have the reference of where you plan to insert
// said linked list. Otherwise, a List is much faster because a LinkedList searches the location of where you would like to insert it
	
private LinkedList <EntityA> eA = new LinkedList<EntityA>();
private LinkedList <EntityB> eB = new LinkedList<EntityB>();

EntityA a;
EntityB b;

public Controller() {
	
	
}





public void tick()
{
	
	
}





public void render()
{
	

}


































}
